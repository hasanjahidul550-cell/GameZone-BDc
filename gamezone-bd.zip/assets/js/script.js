/* ============== DATA ============== */
const PACKAGES = {
  ff: {
    title: "ডায়মন্ড", icon: "💎", uidLabel: "Free Fire UID", uidPlaceholder: "আপনার UID নম্বর দিন",
    items: [
      {amt:100, price:130, bonus:""},
      {amt:310, price:390, bonus:"+10 বোনাস", badge:"জনপ্রিয়"},
      {amt:520, price:640, bonus:"+20 বোনাস"},
      {amt:1060, price:1250, bonus:"+60 বোনাস"},
      {amt:2180, price:2400, bonus:"+180 বোনাস"},
      {amt:5600, price:6000, bonus:"+600 বোনাস", badge:"সেরা ডিল"},
    ]
  },
  coc: {
    title: "জেম", icon: "💚", uidLabel: "Supercell Player Tag", uidPlaceholder: "#XXXXXXXXX",
    items: [
      {amt:80, price:120, bonus:""},
      {amt:500, price:650, bonus:"+50 বোনাস", badge:"জনপ্রিয়"},
      {amt:1200, price:1400, bonus:"+120 বোনাস"},
      {amt:2500, price:2800, bonus:"+300 বোনাস"},
      {amt:6500, price:7000, bonus:"+1000 বোনাস", badge:"সেরা ডিল"},
      {amt:14000, price:14500, bonus:"+2500 বোনাস"},
    ]
  },
  ef: {
    title: "কয়েন", icon: "⚽", uidLabel: "eFootball ID / Email", uidPlaceholder: "আপনার eFootball ID দিন",
    items: [
      {amt:200, price:250, bonus:""},
      {amt:600, price:700, bonus:"+50 বোনাস", badge:"জনপ্রিয়"},
      {amt:1200, price:1300, bonus:"+100 বোনাস"},
      {amt:2600, price:2700, bonus:"+250 বোনাস"},
      {amt:5500, price:5500, bonus:"+700 বোনাস", badge:"সেরা ডিল"},
      {amt:12000, price:11500, bonus:"+2000 বোনাস"},
    ]
  }
};

const GAME_NAMES = { ff: "Free Fire", coc: "Clash of Clans", ef: "eFootball" };

/* ============== PC / CONSOLE GAME STORE DATA ==============
   প্রতিটি গেমের জন্য:
   - name, genre, icon (ইমোজি/আইকন), platforms (যেসব প্ল্যাটফর্মে পাওয়া যায়)
   - price (বর্তমান দাম), oldPrice (আগের/মার্কেট দাম — ঐচ্ছিক), badge (ঐচ্ছিক ট্যাগ)
   - delivery: 'account' (লগইন ডিটেইলস) বা 'code' (অ্যাক্টিভেশন/রিডিম কোড)
   দাম ও তালিকা প্রয়োজন অনুযায়ী এডিট করে নিতে পারবেন। */
const GAME_TITLES = [
  {
    name: "GTA 5 — Grand Theft Auto V",
    genre: "অ্যাকশন / ওপেন ওয়ার্ল্ড",
    icon: "🚗",
    platforms: ["PC", "PS4", "PS5"],
    price: 850, oldPrice: 2500,
    badge: "জনপ্রিয়",
    delivery: "account"
  },
  {
    name: "God of War (2018) / Ragnarök",
    genre: "অ্যাকশন অ্যাডভেঞ্চার",
    icon: "🪓",
    platforms: ["PC", "PS4", "PS5"],
    price: 950, oldPrice: 3200,
    badge: "সেরা ডিল",
    delivery: "account"
  },
  {
    name: "EA Sports FC 25",
    genre: "স্পোর্টস / ফুটবল",
    icon: "⚽",
    platforms: ["PC", "PS4", "PS5"],
    price: 1200, oldPrice: 4500,
    delivery: "code"
  },
  {
    name: "Red Dead Redemption 2",
    genre: "অ্যাকশন / ওপেন ওয়ার্ল্ড",
    icon: "🤠",
    platforms: ["PC", "PS4"],
    price: 900, oldPrice: 3000,
    delivery: "account"
  },
  {
    name: "Spider-Man Remastered",
    genre: "অ্যাকশন অ্যাডভেঞ্চার",
    icon: "🕷️",
    platforms: ["PC", "PS4", "PS5"],
    price: 800, oldPrice: 2800,
    delivery: "account"
  },
  {
    name: "Elden Ring",
    genre: "RPG / সোলসলাইক",
    icon: "⚔️",
    platforms: ["PC", "PS4", "PS5"],
    price: 1400, oldPrice: 4800,
    badge: "ট্রেন্ডিং",
    delivery: "code"
  },
  {
    name: "PUBG: Battlegrounds",
    genre: "ব্যাটল রয়্যাল",
    icon: "🎯",
    platforms: ["PC", "PS4", "PS5"],
    price: 700, oldPrice: 1800,
    delivery: "code"
  },
  {
    name: "Cyberpunk 2077",
    genre: "RPG / সাই-ফাই",
    icon: "🌆",
    platforms: ["PC", "PS4", "PS5"],
    price: 1000, oldPrice: 3500,
    delivery: "account"
  }
];


/* ⚠️ এখানে আপনার নিজের WhatsApp নম্বর বসান (দেশের কোড সহ, + ছাড়া) */
const WHATSAPP_NUMBER = "8801409064279";

/* পেমেন্ট নম্বর — কাস্টমার এই নম্বরে bKash/Nagad/Rocket এ সেন্ড মানি করবে।
   কোনো মেথডের নম্বর ভিন্ন হলে এখানে পরিবর্তন করে দিন (যেমন Rocket আলাদা নম্বর হলে) */
const PAYMENT_NUMBERS = {
  'bKash': '01409064279',
  'Nagad': '01409064279',
  'Rocket': '01409064279'
};

const PAY_LABELS = {
  'bKash': '📱 bKash (Personal) নম্বরে সেন্ড মানি করুন',
  'Nagad': '💚 Nagad (Personal) নম্বরে সেন্ড মানি করুন',
  'Rocket': '🔵 Rocket (Personal) নম্বরে সেন্ড মানি করুন'
};

/* ⚠️⚠️ এখানে আপনার Google Apps Script Web App এর URL বসান
   কিভাবে পাবেন তা নিচের "GOOGLE_SHEET_SETUP.txt" ফাইলে দেওয়া আছে।
   উদাহরণ: "https://script.google.com/macros/s/AKfycb.../exec" */
const SHEET_API_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";

const SESSION_KEY = "gz_bd_session";

const bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
function toBn(num){ return String(num).split('').map(d => /\d/.test(d) ? bn[d] : d).join(''); }

let selectedPkg = {}; // per game
let selectedGameTitle = null; // index into GAME_TITLES

/* ============== BUILD PACKAGE CARDS ============== */
function buildGrids(){
  Object.keys(PACKAGES).forEach(game => {
    const data = PACKAGES[game];
    const grid = document.getElementById('grid-' + game);
    grid.innerHTML = data.items.map((item, idx) => `
      <div class="pkg-card" data-game="${game}" data-idx="${idx}" onclick="selectPkg('${game}',${idx})">
        ${item.badge ? `<div class="pkg-badge">${item.badge}</div>` : ''}
        <span class="pkg-icon">${data.icon}</span>
        <div class="pkg-amount">${item.amt}</div>
        <div class="pkg-label">${data.title}</div>
        <div class="pkg-price">৳${toBn(item.price)}</div>
        ${item.bonus ? `<div class="pkg-bonus">${item.bonus}</div>` : ''}
      </div>
    `).join('');
  });
}

/* ============== BUILD PC/CONSOLE GAME STORE CARDS ============== */
function buildGamesStoreGrid(){
  const grid = document.getElementById('gamesStoreGrid');
  if(!grid) return;
  grid.innerHTML = GAME_TITLES.map((g, idx) => {
    const discount = g.oldPrice ? Math.round((1 - g.price / g.oldPrice) * 100) : 0;
    return `
    <div class="game-store-card" data-idx="${idx}" onclick="selectGameTitle(${idx})">
      <div class="game-store-cover" style="background:linear-gradient(135deg, rgba(124,58,237,0.18), rgba(255,61,0,0.12));">
        ${g.badge ? `<div class="game-store-badge">${g.badge}</div>` : ''}
        <div class="game-store-plat">${g.platforms.join(' / ')}</div>
        ${g.icon}
      </div>
      <div class="game-store-body">
        <div class="game-store-title">${g.name}</div>
        <div class="game-store-genre">${g.genre}</div>
        <div class="game-store-price-row">
          <span class="game-store-price">৳${toBn(g.price)}</span>
          ${g.oldPrice ? `<span class="game-store-old-price">৳${toBn(g.oldPrice)}</span>` : ''}
          ${discount > 0 ? `<span class="game-store-discount">-${discount}%</span>` : ''}
        </div>
      </div>
    </div>
  `;
  }).join('');
}


/* ============== TAB SWITCH ============== */
function switchGame(game){
  document.querySelectorAll('.game-tab').forEach(t => t.classList.toggle('active', t.dataset.game === game));
  document.querySelectorAll('.game-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + game).classList.add('active');
  document.getElementById('shop').scrollIntoView({behavior:'smooth', block:'start'});
}

/* ============== SELECT PACKAGE ============== */
function selectPkg(game, idx){
  const data = PACKAGES[game];
  const item = data.items[idx];
  selectedPkg[game] = idx;

  // Highlight
  document.querySelectorAll(`#grid-${game} .pkg-card`).forEach(c => c.classList.remove('selected'));
  document.querySelector(`#grid-${game} .pkg-card[data-idx="${idx}"]`).classList.add('selected');

  // Build order box
  const box = document.getElementById('order-' + game);
  box.classList.add('show');

  box.innerHTML = `
    <div class="order-title">🛒 অর্ডার ডিটেইলস — ${GAME_NAMES[game]}</div>
    <div class="order-grid">
      <div>
        <div class="field-label">${data.uidLabel}</div>
        <input class="field-input" id="uid-${game}" placeholder="${data.uidPlaceholder}" />
        <div class="field-row">
          <div>
            <div class="field-label">আপনার নাম</div>
            <input class="field-input" id="name-${game}" placeholder="নাম লিখুন" />
          </div>
          <div>
            <div class="field-label">ফোন নম্বর</div>
            <input class="field-input" id="phone-${game}" placeholder="01XXXXXXXXX" />
          </div>
        </div>
        <div class="field-label">পেমেন্ট পদ্ধতি</div>
        <div class="pay-methods" id="pay-${game}">
          <div class="pay-method active" onclick="selectPay(this)">📱 bKash</div>
          <div class="pay-method" onclick="selectPay(this)">💚 Nagad</div>
          <div class="pay-method" onclick="selectPay(this)">🔵 Rocket</div>
        </div>
        <div class="pay-number-box">
          <div class="pay-number-info">
            <span class="pay-number-label">${PAY_LABELS['bKash']}</span>
            <span class="pay-number-value">${PAYMENT_NUMBERS['bKash']}</span>
          </div>
          <button type="button" class="pay-copy-btn" onclick="copyPayNumber(this)">📋 কপি</button>
        </div>
      </div>
      <div class="summary-box">
        <div class="summary-row"><span>প্যাকেজ</span><span class="summary-val">${item.amt} ${data.title}</span></div>
        ${item.bonus ? `<div class="summary-row"><span>বোনাস</span><span class="summary-val" style="color:var(--green);">${item.bonus}</span></div>` : ''}
        <div class="summary-row"><span>মূল্য</span><span class="summary-val">৳${toBn(item.price)}</span></div>
        <div class="summary-row total"><span>মোট</span><span class="val">৳${toBn(item.price)}</span></div>
        <button class="whatsapp-btn" onclick="sendWhatsApp('${game}')">
          <svg viewBox="0 0 32 32" fill="currentColor"><path d="M16.001 3C9.376 3 4 8.373 4 15c0 2.397.7 4.63 1.916 6.516L4 29l7.676-1.875A11.93 11.93 0 0 0 16 27c6.625 0 12-5.373 12-12S22.626 3 16.001 3zm.001 21.75c-1.94 0-3.79-.51-5.396-1.46l-.387-.23-4.55 1.114 1.142-4.434-.252-.402A9.71 9.71 0 0 1 5.25 15c0-5.385 4.366-9.75 9.752-9.75S24.75 9.616 24.75 15 20.388 24.75 16.002 24.75zm5.34-7.32c-.292-.146-1.728-.853-1.996-.95-.268-.097-.463-.146-.658.146-.195.292-.755.95-.926 1.146-.17.195-.34.219-.633.073-.292-.146-1.234-.455-2.35-1.45-.868-.774-1.454-1.73-1.625-2.022-.17-.292-.018-.45.128-.595.131-.13.292-.34.438-.51.146-.17.195-.292.292-.487.097-.195.049-.366-.024-.512-.073-.146-.658-1.585-.902-2.17-.238-.572-.48-.494-.658-.503l-.56-.01c-.195 0-.512.073-.78.366-.268.292-1.025 1.001-1.025 2.44 0 1.44 1.05 2.83 1.196 3.025.146.195 2.066 3.157 5.005 4.428.7.302 1.246.483 1.672.618.702.224 1.342.192 1.847.117.563-.084 1.728-.707 1.972-1.39.243-.683.243-1.268.17-1.39-.073-.122-.268-.195-.56-.34z"/></svg>
          WhatsApp এ অর্ডার পাঠান
        </button>
        <div class="order-note">বাটনে চাপলে WhatsApp খুলবে এবং আপনার অর্ডার তথ্যসহ মেসেজ রেডি থাকবে — শুধু সেন্ড করুন।</div>
      </div>
    </div>
  `;

  box.scrollIntoView({behavior:'smooth', block:'nearest'});
}

function selectPay(el){
  const group = el.parentElement;
  group.querySelectorAll('.pay-method').forEach(m => m.classList.remove('active'));
  el.classList.add('active');

  let method = 'bKash';
  if(el.textContent.includes('Nagad')) method = 'Nagad';
  else if(el.textContent.includes('Rocket')) method = 'Rocket';

  const box = group.parentElement.querySelector('.pay-number-box');
  if(box){
    box.querySelector('.pay-number-label').textContent = PAY_LABELS[method];
    box.querySelector('.pay-number-value').textContent = PAYMENT_NUMBERS[method];
  }
}

/* ============== COPY PAYMENT NUMBER ============== */
function copyPayNumber(btn){
  const numberEl = btn.parentElement.querySelector('.pay-number-value');
  const number = numberEl ? numberEl.textContent.trim() : '';
  if(!number) return;

  const original = btn.textContent;
  const done = () => {
    btn.textContent = '✅ কপি হয়েছে';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = original; btn.classList.remove('copied'); }, 1500);
  };

  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(number).then(done).catch(() => showToast('নম্বর: ' + number, true));
  } else {
    showToast('নম্বর: ' + number, true);
  }
}

/* ============== SEND TO WHATSAPP ============== */
function sendWhatsApp(game){
  const idx = selectedPkg[game];
  const data = PACKAGES[game];
  const item = data.items[idx];

  const uid = document.getElementById('uid-' + game).value.trim();
  const name = document.getElementById('name-' + game).value.trim();
  const phone = document.getElementById('phone-' + game).value.trim();
  const payEl = document.querySelector(`#pay-${game} .pay-method.active`);
  const payment = payEl ? payEl.textContent.trim() : 'bKash';
  const payNumEl = document.querySelector(`#order-${game} .pay-number-value`);
  const payNumber = payNumEl ? payNumEl.textContent.trim() : PAYMENT_NUMBERS['bKash'];

  if(!uid || !name || !phone){
    showToast('⚠️ অনুগ্রহ করে UID, নাম ও ফোন নম্বর পূরণ করুন', false);
    return;
  }

  const lines = [
    `🎮 *নতুন অর্ডার - GameZone BD*`,
    ``,
    `গেম: ${GAME_NAMES[game]}`,
    `প্যাকেজ: ${item.amt} ${data.title}${item.bonus ? ' (' + item.bonus + ')' : ''}`,
    `মূল্য: ৳${item.price}`,
    ``,
    `${data.uidLabel}: ${uid}`,
    `নাম: ${name}`,
    `ফোন: ${phone}`,
    `পেমেন্ট মেথড: ${payment}`,
    `পেমেন্ট নম্বর: ${payNumber}`,
    ``,
    `অনুগ্রহ করে কনফার্ম করুন, ধন্যবাদ! 🙏`
  ];

  const message = encodeURIComponent(lines.join('\n'));
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;

  showToast('✅ WhatsApp খোলা হচ্ছে...', true);
  setTimeout(() => window.open(url, '_blank'), 400);
}

/* General WhatsApp link (header / footer / float button) */
function openGeneralWhatsApp(){
  const text = encodeURIComponent("Hi GameZone BD! আমি একটি অর্ডার সম্পর্কে জানতে চাই।");
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, '_blank');
}

/* ============== SELECT PC/CONSOLE GAME TITLE ============== */
function selectGameTitle(idx){
  const g = GAME_TITLES[idx];
  selectedGameTitle = idx;

  // Highlight
  document.querySelectorAll('#gamesStoreGrid .game-store-card').forEach(c => c.classList.remove('selected'));
  document.querySelector(`#gamesStoreGrid .game-store-card[data-idx="${idx}"]`).classList.add('selected');

  const deliveryText = g.delivery === 'code'
    ? 'এই গেমটি অ্যাক্টিভেশন/রিডিম কোড আকারে ডেলিভারি দেওয়া হবে — অর্ডারের পর কোডটি Steam/Epic/PSN এ রিডিম করতে হবে।'
    : 'এই গেমটি একটি ভেরিফাইড একাউন্ট (লগইন ডিটেইলসসহ) আকারে ডেলিভারি দেওয়া হবে — নির্দেশনা অনুযায়ী ব্যবহার করতে হবে।';

  const box = document.getElementById('gameOrderBox');
  box.classList.add('show');

  box.innerHTML = `
    <div class="order-title">🛒 অর্ডার ডিটেইলস — ${g.name}</div>

    <div class="game-order-summary-card">
      <div class="game-order-summary-icon" style="background:linear-gradient(135deg, rgba(124,58,237,0.18), rgba(255,61,0,0.12));">${g.icon}</div>
      <div class="game-order-summary-info">
        <h4>${g.name}</h4>
        <div class="meta">${g.genre} · ${g.platforms.join(' / ')}</div>
      </div>
      <div class="game-order-summary-price">
        <span class="price">৳${toBn(g.price)}</span>
        ${g.oldPrice ? `<span class="old">৳${toBn(g.oldPrice)}</span>` : ''}
      </div>
    </div>

    <div class="order-grid">
      <div>
        <div class="field-label">প্ল্যাটফর্ম বেছে নাও</div>
        <div class="pay-methods" id="plat-${idx}">
          ${g.platforms.map((p, i) => `<div class="pay-method${i === 0 ? ' active' : ''}" onclick="selectPlatform(this)">${p}</div>`).join('')}
        </div>

        <div class="field-row">
          <div>
            <div class="field-label">আপনার নাম</div>
            <input class="field-input" id="gname-${idx}" placeholder="নাম লিখুন" />
          </div>
          <div>
            <div class="field-label">ফোন নম্বর</div>
            <input class="field-input" id="gphone-${idx}" placeholder="01XXXXXXXXX" />
          </div>
        </div>

        <div class="field-label">যোগাযোগের ইমেইল (ঐচ্ছিক)</div>
        <input class="field-input" id="gemail-${idx}" placeholder="you@example.com" />

        <div class="field-label">পেমেন্ট পদ্ধতি</div>
        <div class="pay-methods" id="gpay-${idx}">
          <div class="pay-method active" onclick="selectPay(this)">📱 bKash</div>
          <div class="pay-method" onclick="selectPay(this)">💚 Nagad</div>
          <div class="pay-method" onclick="selectPay(this)">🔵 Rocket</div>
        </div>
        <div class="pay-number-box">
          <div class="pay-number-info">
            <span class="pay-number-label">${PAY_LABELS['bKash']}</span>
            <span class="pay-number-value">${PAYMENT_NUMBERS['bKash']}</span>
          </div>
          <button type="button" class="pay-copy-btn" onclick="copyPayNumber(this)">📋 কপি</button>
        </div>

        <div class="game-delivery-note">📦 ${deliveryText}</div>
      </div>
      <div class="summary-box">
        <div class="summary-row"><span>গেম</span><span class="summary-val">${g.name}</span></div>
        <div class="summary-row"><span>ক্যাটাগরি</span><span class="summary-val">${g.genre}</span></div>
        <div class="summary-row"><span>ডেলিভারি টাইপ</span><span class="summary-val">${g.delivery === 'code' ? 'অ্যাক্টিভেশন কোড' : 'একাউন্ট ডেলিভারি'}</span></div>
        ${g.oldPrice ? `<div class="summary-row"><span>মার্কেট প্রাইস</span><span class="summary-val" style="text-decoration:line-through;color:#5a4a7a;">৳${toBn(g.oldPrice)}</span></div>` : ''}
        <div class="summary-row total"><span>মোট</span><span class="val">৳${toBn(g.price)}</span></div>
        <button class="whatsapp-btn" onclick="sendGameWhatsApp(${idx})">
          <svg viewBox="0 0 32 32" fill="currentColor"><path d="M16.001 3C9.376 3 4 8.373 4 15c0 2.397.7 4.63 1.916 6.516L4 29l7.676-1.875A11.93 11.93 0 0 0 16 27c6.625 0 12-5.373 12-12S22.626 3 16.001 3zm.001 21.75c-1.94 0-3.79-.51-5.396-1.46l-.387-.23-4.55 1.114 1.142-4.434-.252-.402A9.71 9.71 0 0 1 5.25 15c0-5.385 4.366-9.75 9.752-9.75S24.75 9.616 24.75 15 20.388 24.75 16.002 24.75zm5.34-7.32c-.292-.146-1.728-.853-1.996-.95-.268-.097-.463-.146-.658.146-.195.292-.755.95-.926 1.146-.17.195-.34.219-.633.073-.292-.146-1.234-.455-2.35-1.45-.868-.774-1.454-1.73-1.625-2.022-.17-.292-.018-.45.128-.595.131-.13.292-.34.438-.51.146-.17.195-.292.292-.487.097-.195.049-.366-.024-.512-.073-.146-.658-1.585-.902-2.17-.238-.572-.48-.494-.658-.503l-.56-.01c-.195 0-.512.073-.78.366-.268.292-1.025 1.001-1.025 2.44 0 1.44 1.05 2.83 1.196 3.025.146.195 2.066 3.157 5.005 4.428.7.302 1.246.483 1.672.618.702.224 1.342.192 1.847.117.563-.084 1.728-.707 1.972-1.39.243-.683.243-1.268.17-1.39-.073-.122-.268-.195-.56-.34z"/></svg>
          WhatsApp এ অর্ডার পাঠান
        </button>
        <div class="order-note">বাটনে চাপলে WhatsApp খুলবে এবং আপনার অর্ডার তথ্যসহ মেসেজ রেডি থাকবে — শুধু সেন্ড করুন।</div>
      </div>
    </div>
  `;

  box.scrollIntoView({behavior:'smooth', block:'nearest'});
}

/* Platform pill selection (visual only, used for the WhatsApp message) */
function selectPlatform(el){
  const group = el.parentElement;
  group.querySelectorAll('.pay-method').forEach(m => m.classList.remove('active'));
  el.classList.add('active');
}

/* ============== SEND GAME ORDER TO WHATSAPP ============== */
function sendGameWhatsApp(idx){
  const g = GAME_TITLES[idx];

  const platEl = document.querySelector(`#plat-${idx} .pay-method.active`);
  const platform = platEl ? platEl.textContent.trim() : g.platforms[0];

  const name = document.getElementById('gname-' + idx).value.trim();
  const phone = document.getElementById('gphone-' + idx).value.trim();
  const email = document.getElementById('gemail-' + idx).value.trim();
  const payEl = document.querySelector(`#gpay-${idx} .pay-method.active`);
  const payment = payEl ? payEl.textContent.trim() : 'bKash';
  const payNumEl = document.querySelector(`#gameOrderBox .pay-number-value`);
  const payNumber = payNumEl ? payNumEl.textContent.trim() : PAYMENT_NUMBERS['bKash'];

  if(!name || !phone){
    showToast('⚠️ অনুগ্রহ করে নাম ও ফোন নম্বর পূরণ করুন', false);
    return;
  }

  const lines = [
    `🎮 *নতুন গেম অর্ডার - GameZone BD*`,
    ``,
    `গেম: ${g.name}`,
    `প্ল্যাটফর্ম: ${platform}`,
    `ক্যাটাগরি: ${g.genre}`,
    `ডেলিভারি টাইপ: ${g.delivery === 'code' ? 'অ্যাক্টিভেশন কোড' : 'একাউন্ট ডেলিভারি'}`,
    `মূল্য: ৳${g.price}`,
    ``,
    `নাম: ${name}`,
    `ফোন: ${phone}`,
    email ? `ইমেইল: ${email}` : '',
    `পেমেন্ট মেথড: ${payment}`,
    `পেমেন্ট নম্বর: ${payNumber}`,
    ``,
    `অনুগ্রহ করে কনফার্ম করুন, ধন্যবাদ! 🙏`
  ].filter(Boolean);

  const message = encodeURIComponent(lines.join('\n'));
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;

  showToast('✅ WhatsApp খোলা হচ্ছে...', true);
  setTimeout(() => window.open(url, '_blank'), 400);
}

/* ============== TOAST ============== */
function showToast(msg, success){
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.style.borderColor = success ? '#1ebe5d' : '#ff3d00';
  toast.style.color = success ? '#7af0a8' : '#ffb199';
  toast.style.background = success ? '#0f2818' : '#2a0f0f';
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3200);
}

/* ============== FAQ ============== */
function toggleFaq(el){
  const item = el.parentElement;
  document.querySelectorAll('.faq-item').forEach(f => { if(f !== item) f.classList.remove('open'); });
  item.classList.toggle('open');
}

/* ============== COIN RAIN ============== */
function buildCoinRain(){
  const symbols = ['💎','💚','⚽','🪙'];
  const container = document.getElementById('coinRain');
  for(let i=0;i<18;i++){
    const c = document.createElement('div');
    c.className = 'coin';
    c.textContent = symbols[Math.floor(Math.random()*symbols.length)];
    c.style.left = Math.random()*100 + '%';
    c.style.animationDuration = (8 + Math.random()*10) + 's';
    c.style.animationDelay = (Math.random()*10) + 's';
    c.style.fontSize = (16 + Math.random()*14) + 'px';
    container.appendChild(c);
  }
}

/* ============== DIGITAL ADS ============== */
const AD_PLATFORMS = {
  fb: { name: 'Facebook Ads',   icon: '📘' },
  yt: { name: 'YouTube Ads',    icon: '📺' },
  ig: { name: 'Instagram Ads',  icon: '📸' },
  tt: { name: 'TikTok Ads',     icon: '🎵' },
  gg: { name: 'Google Ads',     icon: '🔍' }
};

function switchAdPlatform(platform){
  document.querySelectorAll('.ad-tab').forEach(t =>
    t.classList.toggle('active', t.dataset.platform === platform));
  document.querySelectorAll('.ad-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('ad-panel-' + platform).classList.add('active');
  // Close all open order boxes
  document.querySelectorAll('.ad-order-box').forEach(b => b.classList.remove('show'));
  document.getElementById('ads').scrollIntoView({behavior:'smooth', block:'start'});
}

function openAdOrder(platform, service, price){
  const p = AD_PLATFORMS[platform];
  const box = document.getElementById('ad-order-box-' + platform);

  // Close other open boxes
  document.querySelectorAll('.ad-order-box').forEach(b => {
    if(b !== box) b.classList.remove('show');
  });

  box.classList.add('show');
  box.innerHTML = `
    <div class="order-title">📋 অর্ডার ফর্ম &mdash; ${p.icon} ${service}</div>
    <div class="ad-form-grid">
      <div>
        <div class="field-label">পেজ / ব্যবসার নাম</div>
        <input class="field-input" id="ad-biz-${platform}" placeholder="আপনার পেজ বা ব্যবসার নাম" />
        <div class="field-row">
          <div>
            <div class="field-label">আপনার নাম</div>
            <input class="field-input" id="ad-name-${platform}" placeholder="নাম লিখুন" />
          </div>
          <div>
            <div class="field-label">ফোন (WhatsApp)</div>
            <input class="field-input" id="ad-phone-${platform}" placeholder="01XXXXXXXXX" />
          </div>
        </div>
        <div class="field-label">বাজেট (টাকায়)</div>
        <input class="field-input" id="ad-budget-${platform}" placeholder="যেমন: ৳২০০০" />
        <div class="field-label">বিস্তারিত (ঐচ্ছিক)</div>
        <textarea class="field-textarea" id="ad-details-${platform}" placeholder="আপনার পণ্য/সেবার বিবরণ, টার্গেট অডিয়েন্স বা অন্য কোনো তথ্য লিখুন..."></textarea>
      </div>
      <div>
        <div class="ad-summary-panel">
          <div class="ad-summary-header">
            <span style="font-size:22px;">${p.icon}</span>
            <strong>${p.name}</strong>
          </div>
          <div class="ad-summary-row">
            <span>সার্ভিস</span>
            <span style="color:#fff;font-weight:600;">${service}</span>
          </div>
          <div class="ad-summary-row">
            <span>মূল্য শুরু</span>
            <span class="ad-summary-price-badge">${price}</span>
          </div>
          <div class="ad-summary-note">
            📝 আপনার বাজেট ও লক্ষ্য অনুযায়ী কাস্টম প্ল্যান তৈরি করে দেওয়া হবে। WhatsApp এ মেসেজ করলে বিস্তারিত জানানো হবে।
          </div>
          <button class="whatsapp-btn" style="margin-top:20px;" onclick="sendAdWhatsApp('${platform}','${service}','${price}')">
            <svg viewBox="0 0 32 32" fill="currentColor"><path d="M16.001 3C9.376 3 4 8.373 4 15c0 2.397.7 4.63 1.916 6.516L4 29l7.676-1.875A11.93 11.93 0 0 0 16 27c6.625 0 12-5.373 12-12S22.626 3 16.001 3zm.001 21.75c-1.94 0-3.79-.51-5.396-1.46l-.387-.23-4.55 1.114 1.142-4.434-.252-.402A9.71 9.71 0 0 1 5.25 15c0-5.385 4.366-9.75 9.752-9.75S24.75 9.616 24.75 15 20.388 24.75 16.002 24.75zm5.34-7.32c-.292-.146-1.728-.853-1.996-.95-.268-.097-.463-.146-.658.146-.195.292-.755.95-.926 1.146-.17.195-.34.219-.633.073-.292-.146-1.234-.455-2.35-1.45-.868-.774-1.454-1.73-1.625-2.022-.17-.292-.018-.45.128-.595.131-.13.292-.34.438-.51.146-.17.195-.292.292-.487.097-.195.049-.366-.024-.512-.073-.146-.658-1.585-.902-2.17-.238-.572-.48-.494-.658-.503l-.56-.01c-.195 0-.512.073-.78.366-.268.292-1.025 1.001-1.025 2.44 0 1.44 1.05 2.83 1.196 3.025.146.195 2.066 3.157 5.005 4.428.7.302 1.246.483 1.672.618.702.224 1.342.192 1.847.117.563-.084 1.728-.707 1.972-1.39.243-.683.243-1.268.17-1.39-.073-.122-.268-.195-.56-.34z"/></svg>
            WhatsApp এ অর্ডার পাঠান
          </button>
          <div class="order-note">বাটনে চাপলে WhatsApp খুলবে এবং আপনার তথ্যসহ মেসেজ রেডি থাকবে — শুধু সেন্ড করুন।</div>
        </div>
      </div>
    </div>
  `;

  setTimeout(() => box.scrollIntoView({behavior:'smooth', block:'nearest'}), 100);
}

function sendAdWhatsApp(platform, service, price){
  const p = AD_PLATFORMS[platform];
  const biz    = document.getElementById('ad-biz-'    + platform).value.trim();
  const name   = document.getElementById('ad-name-'   + platform).value.trim();
  const phone  = document.getElementById('ad-phone-'  + platform).value.trim();
  const budget = document.getElementById('ad-budget-' + platform).value.trim();
  const details= document.getElementById('ad-details-'+ platform).value.trim();

  if(!biz || !name || !phone){
    showToast('⚠️ পেজের নাম, আপনার নাম ও ফোন নম্বর দিন', false);
    return;
  }

  const lines = [
    `📣 *নতুন বিজ্ঞাপন অর্ডার — GameZone BD*`,
    ``,
    `প্ল্যাটফর্ম: ${p.icon} ${p.name}`,
    `সার্ভিস: ${service}`,
    `মূল্য শুরু: ${price}`,
    ``,
    `পেজ/ব্যবসা: ${biz}`,
    `যোগাযোগকারী: ${name}`,
    `ফোন: ${phone}`,
    budget  ? `বাজেট: ${budget}` : '',
    details ? `বিস্তারিত: ${details}` : '',
    ``,
    `অনুগ্রহ করে কনফার্ম করুন, ধন্যবাদ! 🙏`
  ].filter(Boolean);

  const msg = encodeURIComponent(lines.join('\n'));
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`;

  showToast('✅ WhatsApp খোলা হচ্ছে...', true);
  setTimeout(() => window.open(url, '_blank'), 400);
}

/* ============== SCROLL REVEAL ============== */
function setupReveal(){
  const els = document.querySelectorAll('.reveal');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('in'); });
  }, {threshold:0.12});
  els.forEach(el => obs.observe(el));
}

/* ============== AUTH: MODAL CONTROL ============== */
function openAuth(tab){
  document.getElementById('authOverlay').classList.add('show');
  switchAuthTab(tab || 'login');
  clearAuthMsgs();
}
function closeAuth(){
  document.getElementById('authOverlay').classList.remove('show');
  clearAuthMsgs();
}
function closeAuthOnOverlay(e){
  if(e.target.id === 'authOverlay') closeAuth();
}
function switchAuthTab(tab){
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-signup').classList.toggle('active', tab === 'signup');
  document.getElementById('form-login').classList.toggle('active', tab === 'login');
  document.getElementById('form-signup').classList.toggle('active', tab === 'signup');
  clearAuthMsgs();
}
function clearAuthMsgs(){
  ['loginMsg','signupMsg'].forEach(id => {
    const el = document.getElementById(id);
    el.textContent = '';
    el.className = 'auth-msg';
  });
}
function setAuthMsg(id, text, type){
  const el = document.getElementById(id);
  el.textContent = text;
  el.className = 'auth-msg ' + type;
}

/* ============== AUTH: SIMPLE PASSWORD HASH ==============
   নোট: এটি একটি basic SHA-256 hash, ব্যাংকিং-গ্রেড নিরাপত্তা নয়।
   পাসওয়ার্ড সরাসরি Sheet-এ প্লেইন টেক্সটে না রাখার জন্য এটি ব্যবহার করা হচ্ছে। */
async function hashPassword(pw){
  const enc = new TextEncoder().encode(pw);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

/* ============== AUTH: API CALL TO GOOGLE SHEET ============== */
async function callSheetAPI(payload){
  if(!SHEET_API_URL || SHEET_API_URL.indexOf('PASTE_YOUR') !== -1){
    throw new Error('CONFIG_MISSING');
  }
  const res = await fetch(SHEET_API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' }, // avoids CORS preflight on Apps Script
    body: JSON.stringify(payload)
  });
  if(!res.ok) throw new Error('NETWORK_ERROR');
  return await res.json();
}

/* ============== AUTH: SIGNUP ============== */
async function handleSignup(e){
  e.preventDefault();
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value.trim().toLowerCase();
  const password = document.getElementById('signup-password').value;
  const btn = document.getElementById('signupSubmitBtn');

  if(!name || !email || !password){
    setAuthMsg('signupMsg', '⚠️ সব ঘর পূরণ করুন', 'error');
    return;
  }
  if(password.length < 6){
    setAuthMsg('signupMsg', '⚠️ পাসওয়ার্ড কমপক্ষে ৬ ক্যারেক্টার হতে হবে', 'error');
    return;
  }

  btn.disabled = true;
  setAuthMsg('signupMsg', 'অ্যাকাউন্ট তৈরি হচ্ছে...', 'info');

  try{
    const passwordHash = await hashPassword(password);
    const result = await callSheetAPI({
      action: 'signup',
      name, email, passwordHash
    });

    if(result.status === 'success'){
      setAuthMsg('signupMsg', '✅ অ্যাকাউন্ট তৈরি হয়েছে! লগইন করুন...', 'success');
      saveSession({ name, email });
      setTimeout(() => { closeAuth(); showToast('🎉 স্বাগতম, ' + name + '!', true); }, 900);
    } else if(result.status === 'exists'){
      setAuthMsg('signupMsg', '⚠️ এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে। লগইন করুন।', 'error');
    } else {
      setAuthMsg('signupMsg', '❌ কিছু ভুল হয়েছে: ' + (result.message || 'আবার চেষ্টা করুন'), 'error');
    }
  } catch(err){
    if(err.message === 'CONFIG_MISSING'){
      setAuthMsg('signupMsg', '⚠️ Google Sheet এখনও কানেক্ট করা হয়নি। GOOGLE_SHEET_SETUP.txt ফাইল দেখুন।', 'error');
    } else {
      setAuthMsg('signupMsg', '❌ সার্ভারে যোগাযোগ করা যায়নি। ইন্টারনেট চেক করুন।', 'error');
    }
  } finally {
    btn.disabled = false;
  }
}

/* ============== AUTH: LOGIN ============== */
async function handleLogin(e){
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const password = document.getElementById('login-password').value;
  const btn = document.getElementById('loginSubmitBtn');

  if(!email || !password){
    setAuthMsg('loginMsg', '⚠️ ইমেইল ও পাসওয়ার্ড দিন', 'error');
    return;
  }

  btn.disabled = true;
  setAuthMsg('loginMsg', 'লগইন হচ্ছে...', 'info');

  try{
    const passwordHash = await hashPassword(password);
    const result = await callSheetAPI({
      action: 'login',
      email, passwordHash
    });

    if(result.status === 'success'){
      setAuthMsg('loginMsg', '✅ সফলভাবে লগইন হয়েছে!', 'success');
      saveSession({ name: result.name || email.split('@')[0], email });
      setTimeout(() => { closeAuth(); showToast('👋 স্বাগতম ফিরে, ' + (result.name || '') + '!', true); }, 700);
    } else if(result.status === 'invalid'){
      setAuthMsg('loginMsg', '❌ ইমেইল বা পাসওয়ার্ড ভুল।', 'error');
    } else if(result.status === 'notfound'){
      setAuthMsg('loginMsg', '❌ এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট নেই। সাইন আপ করুন।', 'error');
    } else {
      setAuthMsg('loginMsg', '❌ কিছু ভুল হয়েছে: ' + (result.message || 'আবার চেষ্টা করুন'), 'error');
    }
  } catch(err){
    if(err.message === 'CONFIG_MISSING'){
      setAuthMsg('loginMsg', '⚠️ Google Sheet এখনও কানেক্ট করা হয়নি। GOOGLE_SHEET_SETUP.txt ফাইল দেখুন।', 'error');
    } else {
      setAuthMsg('loginMsg', '❌ সার্ভারে যোগাযোগ করা যায়নি। ইন্টারনেট চেক করুন।', 'error');
    }
  } finally {
    btn.disabled = false;
  }
}

/* ============== SESSION MANAGEMENT ============== */
function saveSession(user){
  try{
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }catch(e){ /* ignore storage errors */ }
  renderUserState(user);
}
function loadSession(){
  try{
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  }catch(e){ return null; }
}
function logoutUser(){
  try{ sessionStorage.removeItem(SESSION_KEY); }catch(e){}
  renderUserState(null);
  showToast('👋 লগআউট সম্পন্ন হয়েছে', true);
}
function renderUserState(user){
  const authButtons = document.getElementById('authButtons');
  const userPill = document.getElementById('userPill');

  if(user){
    authButtons.style.display = 'none';
    userPill.style.display = 'flex';
    document.getElementById('userNameDisplay').textContent = user.name;
    document.getElementById('userAvatar').textContent = user.name.trim().charAt(0).toUpperCase();
    // login forms reset
    document.getElementById('form-login').reset();
    document.getElementById('form-signup').reset();
  } else {
    authButtons.style.display = 'flex';
    userPill.style.display = 'none';
  }
}

/* ============== INIT ============== */
document.addEventListener('DOMContentLoaded', () => {
  buildGrids();
  buildGamesStoreGrid();
  buildCoinRain();
  setupReveal();

  ['heroWaBtn','footerWaLink','floatWaBtn'].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.addEventListener('click', (e) => { e.preventDefault(); openGeneralWhatsApp(); });
  });

  // Default select first package of FF on load (optional)
  // selectPkg('ff', 0);
});
