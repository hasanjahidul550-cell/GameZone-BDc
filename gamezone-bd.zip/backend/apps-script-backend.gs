/**
 * GameZone BD — Google Apps Script Backend
 * ==========================================
 * এই স্ক্রিপ্টটি Google Sheets-কে একটি সাধারণ Signup/Login API তে পরিণত করে।
 * ব্যবহারের নিয়ম: ../GOOGLE_SHEET_SETUP.txt ফাইলটি দেখুন।
 *
 * Sheet structure (Row 1 = header):
 *   A: Name | B: Email | C: PasswordHash | D: CreatedAt
 *
 * Endpoints (সব POST, action ফিল্ডের উপর ভিত্তি করে):
 *   { action: "signup", name, email, passwordHash }
 *   { action: "login",  email, passwordHash }
 */

const SHEET_NAME = "Users"; // আপনার শীটের ট্যাব নাম এর সাথে মিলিয়ে নিন

function doPost(e) {
  let response;
  try {
    const data = JSON.parse(e.postData.contents);

    if (data.action === "signup") {
      response = handleSignup(data);
    } else if (data.action === "login") {
      response = handleLogin(data);
    } else {
      response = { status: "error", message: "Unknown action" };
    }
  } catch (err) {
    response = { status: "error", message: err.message };
  }

  return ContentService
    .createTextOutput(JSON.stringify(response))
    .setMimeType(ContentService.MimeType.JSON);
}

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(["Name", "Email", "PasswordHash", "CreatedAt"]);
  }
  return sheet;
}

function findUserRow(sheet, email) {
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][1]).trim().toLowerCase() === email) {
      return { rowIndex: i + 1, row: data[i] };
    }
  }
  return null;
}

function handleSignup(data) {
  const sheet = getSheet();
  const email = String(data.email || "").trim().toLowerCase();
  const name = String(data.name || "").trim();
  const passwordHash = String(data.passwordHash || "");

  if (!email || !name || !passwordHash) {
    return { status: "error", message: "Missing fields" };
  }

  const existing = findUserRow(sheet, email);
  if (existing) {
    return { status: "exists" };
  }

  sheet.appendRow([name, email, passwordHash, new Date().toISOString()]);
  return { status: "success", name: name };
}

function handleLogin(data) {
  const sheet = getSheet();
  const email = String(data.email || "").trim().toLowerCase();
  const passwordHash = String(data.passwordHash || "");

  if (!email || !passwordHash) {
    return { status: "error", message: "Missing fields" };
  }

  const found = findUserRow(sheet, email);
  if (!found) {
    return { status: "notfound" };
  }

  const storedHash = String(found.row[2]);
  if (storedHash !== passwordHash) {
    return { status: "invalid" };
  }

  return { status: "success", name: found.row[0] };
}
